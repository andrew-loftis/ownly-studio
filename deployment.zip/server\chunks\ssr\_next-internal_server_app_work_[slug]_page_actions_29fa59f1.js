module.exports=[31627,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_work_%5Bslug%5D_page_actions_29fa59f1.js.map