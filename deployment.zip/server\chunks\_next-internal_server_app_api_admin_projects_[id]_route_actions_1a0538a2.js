module.exports=[67176,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_projects_%5Bid%5D_route_actions_1a0538a2.js.map