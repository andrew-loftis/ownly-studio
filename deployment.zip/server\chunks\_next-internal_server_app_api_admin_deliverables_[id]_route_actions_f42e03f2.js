module.exports=[60504,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_deliverables_%5Bid%5D_route_actions_f42e03f2.js.map