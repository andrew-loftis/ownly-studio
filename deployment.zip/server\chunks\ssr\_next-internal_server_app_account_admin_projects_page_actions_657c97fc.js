module.exports=[89571,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_account_admin_projects_page_actions_657c97fc.js.map