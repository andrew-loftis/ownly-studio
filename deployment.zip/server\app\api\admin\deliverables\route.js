var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/deliverables/route.js")
R.c("server/chunks/[root-of-the-server]__ecee7084._.js")
R.c("server/chunks/[root-of-the-server]__df7d807e._.js")
R.c("server/chunks/[root-of-the-server]__82fa2ed7._.js")
R.c("server/chunks/[root-of-the-server]__5dee5797._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_deliverables_route_actions_6d4e949f.js")
R.m(80873)
module.exports=R.m(80873).exports
