module.exports=[14138,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_work_page_actions_0cbe1a7f.js.map