var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/deliverables/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__6d83f11d._.js")
R.c("server/chunks/[root-of-the-server]__df7d807e._.js")
R.c("server/chunks/[root-of-the-server]__82fa2ed7._.js")
R.c("server/chunks/[root-of-the-server]__5dee5797._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_deliverables_[id]_route_actions_f42e03f2.js")
R.m(66869)
module.exports=R.m(66869).exports
