var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/projects/route.js")
R.c("server/chunks/[root-of-the-server]__aa65c437._.js")
R.c("server/chunks/[root-of-the-server]__df7d807e._.js")
R.c("server/chunks/[root-of-the-server]__5dee5797._.js")
R.c("server/chunks/[root-of-the-server]__82fa2ed7._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_projects_route_actions_54a1834e.js")
R.m(1279)
module.exports=R.m(1279).exports
