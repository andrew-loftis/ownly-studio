module.exports=[74868,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_account_admin_page_actions_bd49ec91.js.map