var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/polish/route.js")
R.c("server/chunks/[root-of-the-server]__13c25f1a._.js")
R.c("server/chunks/[root-of-the-server]__5dee5797._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_polish_route_actions_5279af4b.js")
R.m(48240)
module.exports=R.m(48240).exports
