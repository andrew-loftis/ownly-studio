module.exports=[88820,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_deliverables_route_actions_6d4e949f.js.map