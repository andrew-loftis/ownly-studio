globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/43bccb86736f54a7.js",
    "static/chunks/248cba0fcb3874ed.js",
    "static/chunks/aab5becddca52488.js",
    "static/chunks/5f42e5fcf0788b33.js",
    "static/chunks/66fec734e07ea4f4.js",
    "static/chunks/turbopack-9367d8b89ade6da2.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];