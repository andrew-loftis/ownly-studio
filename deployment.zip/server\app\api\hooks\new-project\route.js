var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/hooks/new-project/route.js")
R.c("server/chunks/[root-of-the-server]__667fe373._.js")
R.c("server/chunks/[root-of-the-server]__5dee5797._.js")
R.c("server/chunks/_next-internal_server_app_api_hooks_new-project_route_actions_1a456fd4.js")
R.m(62433)
module.exports=R.m(62433).exports
