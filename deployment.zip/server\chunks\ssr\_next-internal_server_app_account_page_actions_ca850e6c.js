module.exports=[69960,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_account_page_actions_ca850e6c.js.map