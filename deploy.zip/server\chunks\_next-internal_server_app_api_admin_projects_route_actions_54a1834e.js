module.exports=[33007,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_projects_route_actions_54a1834e.js.map