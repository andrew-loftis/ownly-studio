module.exports=[54103,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_examples_%5Bslug%5D_page_actions_16aa5230.js.map