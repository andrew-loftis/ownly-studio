module.exports=[96916,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_polish_route_actions_5279af4b.js.map