var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/route.js")
R.c("server/chunks/[root-of-the-server]__ba1d1b72._.js")
R.c("server/chunks/[root-of-the-server]__57bbfb0a._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_6e6cfc55.js")
R.c("server/chunks/[root-of-the-server]__5dee5797._.js")
R.c("server/chunks/_next-internal_server_app_api_checkout_route_actions_414bfd84.js")
R.m(63437)
module.exports=R.m(63437).exports
