module.exports=[77004,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_hooks_new-project_route_actions_1a456fd4.js.map